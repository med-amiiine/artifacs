package com.caceis.dsi.controllers;

import java.util.Iterator;
import java.util.Map;

import org.apache.axiom.om.OMElement;
import org.apache.axis2.AxisFault;
import org.apache.commons.logging.Log;
import org.apache.synapse.commons.json.JsonUtil;
import org.apache.synapse.core.axis2.Axis2MessageContext;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.w3c.dom.*;
import javax.xml.parsers.*;
import java.io.*;


@RestController
@RequestMapping
public class TmcController {
	
	private static final Log LOGGER = LogFactory.getLog(TmcController.class);
	
	@GetMapping("/code-200")
	public ResponseEntity<String> returnOk() {
		return ResponseEntity.status(HttpStatus.OK).body("OK");
	}

	@GetMapping("/code-500")
	public ResponseEntity<String> returnError() {
		int toto = 5 / 0;
		return ResponseEntity.status(HttpStatus.OK).body(String.valueOf(toto));
	}

	@GetMapping("/code-404")
	public ResponseEntity<String> returnNotFound() {
		return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Not Found");
	}

	@GetMapping("/delay/{delay}")
	public ResponseEntity<String> delay(@PathVariable("delay") int delay) throws InterruptedException {
		Thread.sleep(delay * 1000);
		return ResponseEntity.status(HttpStatus.OK).body("delay " + delay + "s");
	}

	@PostMapping("/headers")
	public ResponseEntity<String> ws(@RequestBody String body, @RequestHeader Map<String, String> headers) {
		System.out.println("requestBody ===> " + body.toString());
		headers.forEach((key, value) -> {
			System.out.println(String.format("Header '%s' = %s", key, value));
		});

		return ResponseEntity.status(HttpStatus.OK).body(headers.toString());
	}


}
